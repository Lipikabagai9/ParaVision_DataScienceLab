# Report
To run the qmd report file set working directory as this folder itself i.e.  mth-208-course-project-24group-13/Report
After rendering the qmd in R after setting directory , then run the html file.

Install following packages to run qmd file:
1. ggplot2
2. tidyverse
3. rnaturalearth
4. sf
5. dplyr
6. viridis
