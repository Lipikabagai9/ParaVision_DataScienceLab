# Presentation
Link for the presentation
https://docs.google.com/presentation/d/1inRS1Ih1y09p5m33dOYCnN2N3yQzlLVF/edit?usp=sharing&ouid=101330506519506249645&rtpof=true&sd=true
