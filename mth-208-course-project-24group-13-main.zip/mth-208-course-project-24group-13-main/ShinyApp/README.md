# Shiny App

To run the shiny app, set working directory as this folder itself i.e. mth-208-course-project-24group-13/ShinyApp.

Install following libraries to run the app:
1. shiny
2. ggplot2
3. tidyverse
4. rnaturalearth
5. sf
6. dplyr
7. viridis
8. ggthemes
9. DT
