# Data

Code for all data collection

Install these packages to run the code for data scraping:
1. tidyverse
2. rvest
3. stringr
4. dplyr
5. tibble
